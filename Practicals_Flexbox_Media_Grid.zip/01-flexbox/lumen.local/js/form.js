'use strict';
// The assignment covers client-side validation; no server endpoint is specified.
document.querySelectorAll('form').forEach(form => {
  const status = form.querySelector('[role="status"]');
  form.addEventListener('input', () => { if (status) status.hidden = true; });
  form.addEventListener('submit', event => {
    event.preventDefault();
    if (!form.reportValidity()) return;
    if (status) {
      status.textContent = 'Поля заполнены корректно. Учебная форма: данные не отправляются.';
      status.hidden = false;
    }
  });
});
document.querySelectorAll('[data-product]').forEach(button => {
  button.addEventListener('click', () => {
    const message = document.querySelector('#message');
    if (!message) return;
    message.value = `Хочу узнать подробнее о светильнике «${button.dataset.product}».`;
    document.querySelector('#feedback').scrollIntoView();
    message.focus({preventScroll: true});
  });
});
