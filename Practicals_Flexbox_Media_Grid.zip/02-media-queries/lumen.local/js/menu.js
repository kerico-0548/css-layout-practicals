'use strict';
const menu = document.querySelector('.header__mobilemenu');
const openButton = document.querySelector('.btn-burger');
const closeButton = document.querySelector('.btn-close');
if (menu && openButton && closeButton) {
  function closeMenu(restoreFocus = true) {
    menu.classList.remove('show');
    menu.inert = true;
    openButton.setAttribute('aria-expanded', 'false');
    if (restoreFocus) openButton.focus();
  }
  openButton.addEventListener('click', () => {
    menu.inert = false;
    menu.classList.add('show');
    openButton.setAttribute('aria-expanded', 'true');
    closeButton.focus();
  });
  closeButton.addEventListener('click', () => closeMenu());
  menu.querySelectorAll('a').forEach(link => link.addEventListener('click', () => closeMenu(false)));
  document.addEventListener('keydown', event => {
    if (!menu.classList.contains('show')) return;
    if (event.key === 'Escape') { closeMenu(); return; }
    if (event.key !== 'Tab') return;
    const items = [...menu.querySelectorAll('a, button')];
    const first = items[0], last = items[items.length - 1];
    if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
    else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
  });
  document.addEventListener('click', event => {
    if (menu.classList.contains('show') && !menu.contains(event.target) && !openButton.contains(event.target)) closeMenu(false);
  });
  window.matchMedia('(min-width: 641px)').addEventListener('change', event => { if (event.matches) closeMenu(false); });
}
